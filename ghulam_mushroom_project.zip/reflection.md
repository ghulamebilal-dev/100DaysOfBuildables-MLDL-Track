What worked? Pipeline with one-hot encoding and RandomForest integrated in Streamlit.

What didn't? Small sample leads to unreliable metrics; use full mushrooms.csv for real results.

Most insightful viz: Cap color vs Edibility bar chart.